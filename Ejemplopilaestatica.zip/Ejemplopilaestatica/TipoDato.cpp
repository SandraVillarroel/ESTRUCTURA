
#include "TipoDato.h"


TipoDatos::TipoDato(void)
{
}


TipoDatos::~TipoDato(void)
{
}


void TipoDato::set_TipoDato(int valor, string desc);
{
	id = valor;
	descripcion = desc;
}
